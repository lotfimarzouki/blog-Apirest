<?php

class Post
{
    //Etablir la connexion à la db
    private $connection;
    private $table = 'posts';
    //Propriété de la table posts
    public $id;
    public $categorie;
    public $title;
    public $contenu;
    public $image;
    //  public $created_at;
    //Constructeur avec la BD
    public function __construct($db)
    {
        $this->connection = $db;
    }
    // Méthode pour lire les articles
    public function read()
    {
        //Création de la requête pour récupérer les articles
        $query = 'SELECT 
          
            id,
            categorie,
            title,
            contenu,
            image
            FROM ' . $this->table;
        /*  LEFT JOIN
              categories c ON p.category_id = c.id
            ORDER By
              p.created_at DESC' */

        //Préparation statement
        $stmt = $this->connection->prepare($query);

        //Execution de la requête
        $stmt->execute();

        return $stmt;
    }
    //Méthode pour lire un seul article via son ID
    public function read_single()
    {
        //Création de la requête pour récupérer 1 article
        $query = 'SELECT * FROM ' . $this->table . 'WHERE  id = ? LIMIT 0,1';
        /*   $query = 'SELECT 
            c.name as category_name,
            p.id,
            p.category_id,
            p.title,
            p.body,
            p.author,
            p.created_at
            FROM ' . $this->table . ' p
            LEFT JOIN
              categories c ON p.category_id = c.id
            WHERE
            p.id = ?
            LIMIT 0,1'; */
        //Préparation statement
        $stmt = $this->connection->prepare($query);
        //BIND ID
        $stmt->bindParam(1, $this->id);
        //Execution de la requête
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        // Appliquer les propriétés
        $this->categorie = $row['categorie'];
        $this->title = $row['title'];
        $this->contenu = $row['contenu'];
        $this->image = $row['image'];
    }
    //Méthode pour crée un article dans la DB
    public function create()
    {
        //Création de la requête pour crée un article
        $query = 'INSERT INTO ' . $this->table . '
                SET
                     categorie= :categorie,
                    title = :title,
                    contenu = :contenu,
                    image= :image';

        //Préparation statement
        $stmt = $this->connection->prepare($query);

        //Sécurité
        $this->categorie = htmlspecialchars(strip_tags($this->categorie));
        $this->title = htmlspecialchars(strip_tags($this->title));
        $this->contenu = htmlspecialchars(strip_tags($this->contenu));
        $this->image = htmlspecialchars(strip_tags($this->image));


        //BindParam
        $stmt->bindParam(':categorie', $this->categorie);
        $stmt->bindParam(':title', $this->title);
        $stmt->bindParam(':contenu', $this->contenu);
        $stmt->bindParam(':image', $this->image);


        //Execute la requête
        if ($stmt->execute()) {
            return true;
        }

        //Afficher une erreur si il y a un problème
        printf("Erreur: %s.\n", $stmt->error);
        return false;
    }


    //Méthode pour mettre à jour un article dans la DB
    public function update()
    {
        //Création de la requête pour crée un article
        $query = 'UPDATE ' . $this->table . '
                SET
                    categorie = :categorie,
                    title = :title,
                    contenu = :contenu,
                    image = :image
                    
                    WHERE
                    id = :id';

        //Préparation statement
        $stmt = $this->connection->prepare($query);

        //Sécurité
        $this->categorie = htmlspecialchars(strip_tags($this->categorie));
        $this->title = htmlspecialchars(strip_tags($this->title));
        $this->contenu = htmlspecialchars(strip_tags($this->contenu));
        $this->image = htmlspecialchars(strip_tags($this->image));

        $this->id = htmlspecialchars(strip_tags($this->id));

        //BindParam
        $stmt->bindParam(':categorie', $this->categorie);
        $stmt->bindParam(':title', $this->title);
        $stmt->bindParam(':contenu', $this->contenu);
        $stmt->bindParam(':image', $this->image);

        $stmt->bindParam(':id', $this->id);

        //Execute la requête
        if ($stmt->execute()) {
            return true;
        }

        //Afficher une erreur si il y a un problème
        printf("Erreur: %s.\n", $stmt->error);
        return false;
    }


    //Méthode pour supprimer un article
    public function delete()
    {

        //Requête pour supprimer un article
        $query = 'DELETE FROM ' . $this->table .  ' WHERE id = :id';

        //Préparation statement
        $stmt = $this->connection->prepare($query);

        //Sécurité
        $this->id = htmlspecialchars(strip_tags($this->id));

        //Bind
        $stmt->bindParam(':id', $this->id);

        //Execute la requête
        if ($stmt->execute()) {
            return true;
        }

        //Afficher une erreur si il y a un problème
        printf("Erreur: %s.\n", $stmt->error);
        return false;
    }
}
