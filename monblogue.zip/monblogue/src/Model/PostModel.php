<?php
// Dans src/Model/PostModel.php
namespace src\Model;

class PostModel
{
    private $db;
    public function __construct($db)
    {
        $this->db = $db;
    }
    public function create($categorie, $title, $contenu, $image)
    {
        $stmt = $this->db->prepare("INSERT INTO posts (categorie,title, contenu,image) VALUES (?, ?, ?, ?)");
        $stmt->execute([$categorie, $title, $contenu, $image]);
        return $this->db->lastInsertId();
    }

    public function readAll()
    {
        $stmt = $this->db->query("SELECT * FROM posts");
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function readById($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM posts WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(\PDO::FETCH_ASSOC);
    }

    public function update($id, $categorie, $title, $contenu, $image)
    {
        $stmt = $this->db->prepare("UPDATE posts SET categorie=?,title = ?, contenu = ?,image=? WHERE id = ?");
        return $stmt->execute([$categorie, $title, $contenu, $image, $id]);
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM posts WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
