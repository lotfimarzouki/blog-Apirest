<?php

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
//use Slim\Http\Response;
use Slim\Factory\AppFactory;

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../src/Model/Database.php';
require __DIR__ . '/../src/Model/Post.php';
require __DIR__ . '/../src/Model/PostModel.php';
// Créer l'application Slim
$app = AppFactory::create();
$app->setBasePath('/monblogue/public');
// Configurer la connexion à la base de données (remplacez par vos paramètres)
$dbSettings = [
	'host' => 'localhost',
	'database' => 'blogue',
	'username' => 'root',
	'password' => ''
];
$database = new Database();
$db = $database->connect();
//Instancié l'objet Post
$post = new Post($db);
$postModel = new \src\Model\PostModel($db);
// Créer une nouvelle route pour récupérer tous les articles
$app->get('/posts', function (Request $request, Response $response) use ($postModel) {
	$posts = $postModel->readAll();
	if (count($posts) > 0) {
		$product = $posts;
		$response->getBody()->write(json_encode($product));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
	} else {
		$response->getBody()->write(json_encode(['message' => 'No articles found.']));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
	}
});


$app->post('/posts', function (Request $request, Response $response) use ($postModel) {
	$data = $request->getParsedBody();

	var_dump($data);
	$categorie = $data['categorie'];
	$title = $data['title'];
	$contenu = $data['contenu'];
	$image = $data['image'];

	if (empty($categorie) || empty($title) || empty($contenu) || empty($image)) {
		$response->getBody()->write(json_encode(['Erreur' => "Les paramètres d'un article ne sont pas corrects"]));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
	} else {
		$postId = $postModel->create($categorie, $title, $contenu, $image);
		$response->getBody()->write(json_encode(['success' => 'Un article est ajouté', 'id' => $postId]));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
	}
});


// Créer une nouvelle route pour récupérer un article par son ID
$app->get('/posts/{id}', function (Request $request, Response $response, $args) use ($postModel) {
	$postId = $args['id'];
	$post = $postModel->readById($postId);

	if ($post) {
		$response->getBody()->write(json_encode($post));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
	} else {
		$response->getBody()->write(json_encode(['error' => 'Produit non trouvé']));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
	}
});
// Créer une nouvelle route pour mettre à jour un article par son ID
$app->put('/posts/{id}', function (Request $request, Response $response, $args) use ($postModel) {
	$postId = $args['id'];
	$data = $request->getParsedBody();
	$success = $postModel->update($postId, $data['categorie'], $data['title'], $data['contenu'], $data['image']);

	if ($success) {
		$response->getBody()->write(json_encode(['message' => 'Article mis à jour avec succès']));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
	} else {
		$response->getBody()->write(json_encode(['error' => 'Article non trouvé']));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
	}
});
// Créer une nouvelle route pour supprimer un article par son ID
$app->delete('/posts/{id}', function (Request $request, Response $response, $args) use ($postModel) {
	$postId = $args['id'];
	$success = $postModel->delete($postId);
	if ($success) {
		$response->getBody()->write(json_encode(['message' => 'Article supprimé avec succès']));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
	} else {
		$response->getBody()->write(json_encode(['error' => 'Article non trouvé']));
		return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
	}
});

// Exécuter l'application
$app->run();
