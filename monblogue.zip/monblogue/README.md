# Tp2: API RESTFUL de la plateforme blog

# Fait par Lotfi El Marzouki

# Objectif

Transformation l'application backend existante (Plateforme du Blog vu dans le cours) en une application API RESTful orientée objet.

### Utilisation

-Descompresser le dossier.
-Demarrer visual studio et ouvrer le dossier MonBlogue.
-Exécutez `php -S localhost:3000` pour démarrer l'application.
-executer le script pour la base de donnee blogue.sql
-ecrire l url dans postman :
-pour lire tous les articles:GET, http://localhost:3000/MonBlogue/public/posts
-pour lire un article par id exemple :GET, http://localhost:3000/MonBlogue/public/posts/17
-pour creer un article: POST, http://localhost:3000/MonBlogue/public/posts
-pour modifier un article, il faut specifier le id de l aticle dans l url : exemple
UPDATE, http://localhost:3000/MonBlogue/public/posts/17

# Slim Framework 4 Skeleton Application

-vous pouvez voir le fichier "ecran postman Tp2"avec des imprimes ecran des tests fait sur postman en format word.
