# Tp2: API RESTFUL de la plateforme blog

# Fait par Lotfi El Marzouki

# Objectif

Transformation l'application backend existante (Plateforme du Blog vu dans le cours) en une application API RESTful orientée objet.
Vous pouvez voir le fichier "ecran postman Tp2"avec des imprimes ecran des tests fait sur postman en format word.

### Utilisation

Rendez-vous sur GitHub : Ouvrez votre navigateur web et allez sur la page GitHub à l'adresse suivante : https://github.com/lotfimarzouki/blog-Apirest

-Descompresser le dossier monblogue.zip
-Demarrer visual studio et ouvrer le dossier monblogue.
-Exécutez `php -S localhost:3000` pour démarrer l'application.
-executer le script pour la base de donnee blogue.sql
-ecrire l url dans postman :
-pour lire tous les articles:GET, http://localhost:3000/monblogue/public/posts
-pour lire un article par id exemple :GET, http://localhost:3000/monblogue/public/posts/17
-pour creer un article: POST, http://localhost:3000/monblogue/public/posts
-pour modifier un article, il faut specifier le id de l article dans l url : exemple
UPDATE, http://localhost:3000/monblogue/public/posts/17
